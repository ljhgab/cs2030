/**
 * Name         :
 * Matric. No   :
*/

import java.util.*;

public class Nearest {
    private void run() {
    }

    public static void main(String args[]) {
        Nearest runner = new Nearest();
        runner.run();
    }
}
