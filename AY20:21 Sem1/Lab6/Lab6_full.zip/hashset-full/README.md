Hi guys
There are 4 files in the solution folder. Only Hashset.java & Long.cpp are correct solutions, the other are wrong solution we wrote to test our testcases. Hashset.java is written by Tuan and Long.cpp is, well, written by me! You guys can read both of them to say our different approach for this hashing problem!

Thank you!