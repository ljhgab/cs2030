/**
 * Name         :
 * Matric. No   :
*/

import java.util.*;

public class Hashset {
    private void run() {
    }

    public static void main(String args[]) {
        Hashset runner = new Hashset();
        runner.run();
    }
}
