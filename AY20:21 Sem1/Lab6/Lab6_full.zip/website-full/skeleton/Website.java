/**
 * Name         :
 * Matric. No   :
*/

import java.util.*;

public class Website {
    private void run() {
    }

    public static void main(String args[]) {
        Website runner = new Website();
        runner.run();
    }
}
