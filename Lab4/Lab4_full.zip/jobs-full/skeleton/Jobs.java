/**
 * Name         :
 * Matric. No   :
*/

import java.util.*;

public class Jobs {
    private void run() {
    }

    public static void main(String args[]) {
        Jobs runner = new Jobs();
        runner.run();
    }
}
