/**
 * Name         :
 * Matric. No   :
*/

import java.util.*;

public class Movies {
    private void run() {
    }

    public static void main(String args[]) {
        Movies runner = new Movies();
        runner.run();
    }
}
