/**
 * Name         :
 * Matric. No   :
*/

import java.util.*;

public class Movies {
	private int n, m;
	private long answer = 0;

	public static class Movie {
		public int L, R, S;

		public Movie(int L, int R, int S) {
			this.L = L;
			this.R = R;
			this.S = S;
		}

		public boolean intersect(Movie other) {
			if (this.R <= other.L) {
				return false;
			}
			if (other.R <= this.L) {
				return false;
			}
			return true;
		}
	}

	private Movie[] movies;

	private void backtrack(int pos, boolean[] chosen, int taken, long sum) {
		if (pos == n) {
			answer = Math.max(answer, sum);
			return;
		}

		chosen[pos] = false;
		backtrack(pos + 1, chosen, taken, sum);
		chosen[pos] = false;

		if (taken < m) {
			for (int i = 0; i < pos; i++) {
				if (chosen[i] && movies[pos].intersect(movies[i])) {
					return;
				}
			}
			///valid
			chosen[pos] = true;
			backtrack(pos + 1, chosen, taken + 1, sum + movies[pos].S);
			chosen[pos] = false;
		}
	}


    private void run() {
    	Scanner sc = new Scanner(System.in);
    	n = sc.nextInt();
    	m = sc.nextInt();

    	movies = new Movie[n];
    	for (int i = 0; i < n; i++) {
    		int L = sc.nextInt(), R = sc.nextInt(), S = sc.nextInt();
    		movies[i] = new Movie(L, R, S);
    	}

    	boolean[] chosen = new boolean[n];
    	backtrack(0, chosen, 0, 0);

    	System.out.println(answer);
    }

    public static void main(String args[]) {
        Movies runner = new Movies();
        runner.run();
    }
} 
