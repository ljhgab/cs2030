/**
 * Name         :
 * Matric. No   :
*/

import java.util.*;

public class Palindrome {
    private void run() {
    }

    public static void main(String args[]) {
        Palindrome runner = new Palindrome();
        runner.run();
    }
}
